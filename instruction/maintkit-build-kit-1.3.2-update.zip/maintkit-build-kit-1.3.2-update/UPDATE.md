# Updating maintkit to 1.3.2

This archive carries every kit file of 1.3.2. Run:

```
sh apply.sh <path to your build-kit folder>
```

It replaces the kit's files, removes files older releases shipped that this
one does not (removed.txt), and never touches `tasks/` or `notes/`.
Then run `./maintkit --version`: it prints 1.3.2. Re-run
`maintkit pack` for any task you have not uploaded yet.
