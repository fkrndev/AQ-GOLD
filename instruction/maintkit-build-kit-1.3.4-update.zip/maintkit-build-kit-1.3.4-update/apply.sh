#!/usr/bin/env sh
set -e
KIT="${1:?usage: sh apply.sh /path/to/build-kit}"
[ -f "$KIT/maintkit" ] && [ -f "$KIT/lib/maintkit.mjs" ] || { echo "not a build-kit folder: $KIT"; exit 1; }
KIT="$(cd "$KIT" && pwd -P)"
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$HERE/removed.txt" ]; then
  while read -r f; do
    case "$f" in ''|/*|..|../*|*/..|*/../*) continue ;; esac
    # Only inside the kit, symlinked folders resolved.
    d="$(cd "$(dirname "$KIT/$f")" 2>/dev/null && pwd -P)" || continue
    case "$d" in "$KIT"|"$KIT"/*) ;; *) continue ;; esac
    [ -e "$KIT/$f" ] && rm -f "$KIT/$f" && echo "removed $f"
  done < "$HERE/removed.txt"
fi
cd "$HERE/files"
find . -type f | sed 's#^\./##' | sort | while read -r f; do
  mkdir -p "$KIT/$(dirname "$f")"
  if [ -f "$KIT/$f" ] && cmp -s "$f" "$KIT/$f"; then :; else cp "$f" "$KIT/$f"; echo "updated $f"; fi
done
chmod +x "$KIT/maintkit"
echo "maintkit is now $(cat "$KIT/lib/rules.json" | sed -n 's/.*"kit": *"\([^"]*\)".*/\1/p' | head -1)"
